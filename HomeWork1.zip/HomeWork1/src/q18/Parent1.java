package q18;

public abstract class Parent1 {
	
	public abstract boolean checkUP(String a);
	public abstract int StringToInt(String a);
	public abstract String lowerToUpper(String a);
}
