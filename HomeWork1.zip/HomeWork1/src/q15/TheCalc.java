package q15;

public interface TheCalc {
public abstract double add();
public abstract double subtract();
public abstract double multiply();
public abstract double divide();

}
