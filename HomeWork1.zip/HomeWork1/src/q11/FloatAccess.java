package q11;

import q9.Primes;

public class FloatAccess {
static Primes a=new Primes();



public static void main(String[] args) {
	
	float z=a.g;
	float b=a.p;
	
	System.out.println(b+" : "+z);
	
}
}
